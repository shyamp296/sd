const mongoose = require('mongoose')

const Schema = mongoose.Schema

const customerSchema = new Schema({
    Fullname: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
    },
    phone: {
        type: Number,
        required: true
    },
    DOB: {
        type: Date,
        required: true
    },
    city: {
        type: String,
        required: true
    },
    userId: {
        type: Schema.Types.ObjectId,
        ref: 'user',
        required: true
    }

}
)

module.exports = mongoose.model('customer', customerSchema)