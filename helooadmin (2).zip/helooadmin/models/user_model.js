const mongoose = require('mongoose')

const Schema  = mongoose.Schema

const userSchema  = new Schema({
    Fullname : {
        type: String,
        required : true 
    },
    email : {
        type : String,
        required : true
    },
    Password :{
        type : String,
        required : true
    },
    phone : {
        type : Number,
        required : true
    },
    DOB : {
        type : Date,
        required : true
    },
    city : {
        type : String,
        required : true
    }
}
)

module.exports = mongoose.model('User', userSchema)