const path = require('path')


const express = require('express')

const router = express.Router()

// const userModel = require('../models/user_model')
const userController = require('../controller/user_Controller')

const auth = require('../middleware/auth')



router.get('/', auth, userController.dashbord)
// add customer
router.get('/add-customer', auth, userController.addCustomer)
router.post('/add-customer', auth, userController.postAddCustomer)

// update Customer
// router.get('/updateCustomer',auth , userController.updateCustomer)
// router.post('/updateCustomer',auth , userController.postupdateCustomer)

// delete Customer
router.post('/deleteCustomer', auth, userController.deleteCustomer)
// display services
router.get('/services', auth, userController.getServices)

//add services
router.get('/add-service', auth, userController.getAddService)
router.post('/add-service', auth, userController.postAddService)


module.exports = router