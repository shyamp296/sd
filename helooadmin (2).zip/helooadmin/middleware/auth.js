const jwt = require('jsonwebtoken')
const User = require('../models/user_model')


const SECRET_KEY = "Shyamdadhaniya"

const auth = (res, req, next) => {


    try {

        const token = res.cookies.token
        if(token){
        const users = jwt.verify(token, SECRET_KEY)
        
        
        req.users = users
    
        id = users.id
        // const user =  User.findOne({ _id:  id })
        //     console.log(user);
        // email = users.email
        next()

        }else { 
            return req.redirect('/sign-In')
        }
    } catch (error) {
        
        console.log(error);
    }
}

module.exports = auth