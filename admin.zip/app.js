const express = require('express')
const mongoose = require('mongoose')
let PORT = process.env.PORT || 9000


const bodyParser = require('body-parser')
const path = require('path')
const cookieParser = require('cookie-parser')
const nodeMailer = require ('nodemailer')
const app = express()

app.set('view engine', 'ejs')

const userRoutes = require('./routes/user_Route')

const authRoutes = require('./routes/auth_routes')

const adminRoutes = require('./routes/admin_routes')
// const multer = require('multer')


app.use(bodyParser.urlencoded({ extended: false }))

app.use(express.static(path.join(__dirname, 'public')))
// app.use(express.static(path.join(__dirname, 'uploads')))
// app.use(multer({ storage: storage , fileFilter : fileFilter }).single('image'))

// calling routes
app.use(cookieParser())

app.use(userRoutes)
app.use(authRoutes)
app.use(adminRoutes)


//connection with databse & listening port

mongoose.set('strictQuery', true)
mongoose.connect('mongodb://localhost:27017/node_practicle-4').then((result) => {
    app.listen(PORT)
    console.log(`connection succesful on port ${PORT}`);
}).catch((err) => {
    console.log(err);
});
