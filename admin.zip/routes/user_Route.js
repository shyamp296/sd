const path = require('path')


const express = require('express')

const router = express.Router()

// const userModel = require('../models/user_model')
const userController = require('../controller/user_Controller')

const auth = require('../middleware/auth')



router.get('/', auth, userController.dashbord)
router.get('/add-customer', auth, userController.addCustomer)
router.post('/add-customer', auth, userController.postAddCustomer)
router.get('/services', auth, userController.getServices)
// router.get('/Servieeces', auth, userController.getServices)

router.post('/add-service', auth, userController.getAddService)
router.post('/padd-service', auth, userController.postAddService)


module.exports = router