const path = require('path')
const User = require('../models/user_model')
const service = require('../models/service_model')
const customer = require('../models/customer_model')

//get dashboard
exports.dashbord = async (req, res, next) => {
   
   
    const customers = await customer.find({ userId : id})
        res.render('home',{
            pagetitle: 'Dashboard',
            customers,
            id
        }
    )
}

//add customer 
exports.addCustomer = async (req, res, next) => {

    res.render('addCustomer', {
        pagetitle: 'Add Customer'
    })
}

//post add customer
exports.postAddCustomer = async (req, res, next) => {
  
    const { Fullname, email, phone, DOB, city,userId } = req.body
    console.log(req.body);

    const customers = new customer({
        Fullname,
        email,
        phone,
        DOB,
        city,
        userId
    })
    await customers.save().then( ()=> { 
        res.redirect('/')
    })
}

//get services 

exports.getServices = async (req, res, next) => {
    
    const id = req.body.id
    console.log(id);
    const services = await service.find({id})
    res.render('services',{
        pagetitle: 'Services',
        services,
        id
    
    })

}

// get add service

exports.getAddService = async (req, res, next) =>{
    const cid = req.body.cid
    res.render('addServices',{
        pagetitle: 'Add Service',
        cid
    })
}

//post add service
exports.postAddService = async (req, res, next) =>{
    const { vehicle_no, Pickup_date, Drop_date, location, Price, customerId } = req.body
    console.log(req.body.customerId);
    const services = new service({
        vehicle_no,
        Pickup_date,
        Drop_date,
        location,
        Price,
        customerId
    })

    services.save().then((r) =>{
        console.log(r);
        res.redirect('/Services')
    })
}
